// Select elements
const chatbotIcon = document.getElementById("chatbot-icon");
const chatWindow = document.getElementById("chat-window");
const closeChat = document.getElementById("close-chat");
const chatBody = chatWindow.querySelector(".chat-body");
const chatOptions = chatWindow.querySelector(".chat-options");

// Chatbot messages and options
const chatbotMessages = {
    welcome: "🤖 Hi there! How can I assist you today?",
    thankYou: "Thank you for chatting! Have a great day! 😊",
    services: "💼 We offer: Web development, e-commerce sites, billing software, and AI integration.",
    courses: "📚 Available courses: Full stack, frontend, backend with internship.",
    projects: "🚀 Recent projects include portfolio development and data analytics tools.",
    contact: "📞 For more info, contact us at 9849494903 or email us at support@example.com.",
};

// Function to toggle chat visibility
const toggleChat = () => {
    chatWindow.classList.toggle("hidden");
};

// Function to add a new message to the chat body
const addMessage = (text, type = "bot") => {
    const message = document.createElement("div");
    message.classList.add("message", type);
    message.innerHTML = text;
    chatBody.appendChild(message);
    chatBody.scrollTop = chatBody.scrollHeight; // Auto-scroll to the latest message
};

// Handle chatbot icon click
chatbotIcon.addEventListener("click", () => {
    toggleChat();
    if (!chatBody.querySelector(".message.bot")) {
        // Add the welcome message and dynamic options
        addMessage(chatbotMessages.welcome);
        chatOptions.innerHTML = `
            <button class="chat-btn small" data-target="services">Services</button>
            <button class="chat-btn small" data-target="courses">Courses</button>
            <button class="chat-btn small" data-target="projects">Projects</button>
            <button class="chat-btn small" data-target="contact">Contact Us</button>
        `;
    }
});

// Handle close button click
closeChat.addEventListener("click", () => {
    toggleChat();
    chatBody.innerHTML = ""; // Clear messages on close
    chatOptions.innerHTML = ""; // Clear buttons
});

// Handle button clicks in the chat options
chatOptions.addEventListener("click", (event) => {
    const target = event.target.dataset.target;
    if (target && chatbotMessages[target]) {
        // Display the user question
        addMessage(`<span class="emoji">🙂</span> ${event.target.textContent}`, "user");

        // Display the chatbot response with a delay for realism
        setTimeout(() => addMessage(chatbotMessages[target]), 1000);
    }
});
