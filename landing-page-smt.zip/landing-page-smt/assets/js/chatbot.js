function toggleChatbot() {
    var chatbot = document.getElementById("chatbot-container");
    chatbot.style.display = (chatbot.style.display === "none" || chatbot.style.display === "") ? "block" : "none";
}

function showAnswer(questionNumber) {
    let answerText = "";

    switch (questionNumber) {
        case 1:
            answerText = "We offer web development, app development, and AI-powered eCommerce solutions.";
            break;
        case 2:
            answerText = "You can contact us via email at contact@yourcompany.com.";
            break;
        case 3:
            answerText = "We are located at 1234 Business St, Your City, Your Country.";
            break;
        case 4:
            answerText = "Our pricing depends on the service and project scope. Contact us for a quote.";
            break;
        case 5:
            answerText = "We offer a 30-day return policy on all purchases.";
            break;
        case 6:
            answerText = "Yes, we offer custom designs based on your requirements.";
            break;
        case 7:
            answerText = "Our average delivery time is 7-10 business days.";
            break;
        case 8:
            answerText = "You can place an order through our website by selecting the products and checking out.";
            break;
        case 9:
            answerText = "Yes, we provide customer support 24/7. Feel free to reach out anytime!";
            break;
        case 10:
            answerText = "Yes, you can track your order by logging into your account on our website.";
            break;
        default:
            answerText = "Please select a valid question.";
    }

    document.getElementById("answer-section").innerHTML = answerText;
}
